<?php
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "login";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);
?>