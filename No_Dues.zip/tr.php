<!DOCTYPE html>
<html>
<head>
<style>

#tr1{
    height:50px;
    display:block;
    text-align:center;
    font-size:40px;
    text-decoration: underline;
}
#table1 {
    border-collapse: collapse;
    width: 100%;
}
#tr2{
    background-color: #4CAF50;
    color: white;
}
</style>
</head>
<body>

<span id="tr1"> Students Data </span>
<table id="table1">
  <tr id="tr2">
    <td>Roll No</td>
    <td>Name</td>
    <td>Dues(Rs.)</td>
    <td>Select ALL<input type="checkbox" style="zoom:1.5"></td>
    <td>Comment</td>
  </tr>
</table>
</body>
</html>
